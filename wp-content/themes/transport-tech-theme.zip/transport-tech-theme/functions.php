<?php
/**
 * Theme functions and definitions
 */

// Theme setup
function transport_tech_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Menú Principal', 'transport-tech'),
        'footer-services' => __('Servicios (Pie de página)', 'transport-tech'),
        'footer-company' => __('Empresa (Pie de página)', 'transport-tech'),
        'footer-legal' => __('Legal (Pie de página)', 'transport-tech'),
    ));
}
add_action('after_setup_theme', 'transport_tech_setup');

// Enqueue scripts and styles
function transport_tech_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style('transport-tech-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue custom CSS
    wp_enqueue_style('transport-tech-custom', get_template_directory_uri() . '/assets/css/custom.css', array(), '1.0.0');
    
    // Enqueue responsive CSS
    wp_enqueue_style('transport-tech-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array(), '1.0.0');
    
    // Enqueue Font Awesome for icons
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css');
    
    // Enqueue main JavaScript
    wp_enqueue_script('transport-tech-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array('jquery'), '1.0.0', true);
    
    // Enqueue custom JavaScript
    wp_enqueue_script('transport-tech-custom', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'transport_tech_scripts');

// Register custom post types
function transport_tech_register_post_types() {
    // Register Service post type
    register_post_type('service', array(
        'labels' => array(
            'name' => __('Servicios', 'transport-tech'),
            'singular_name' => __('Servicio', 'transport-tech'),
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-clipboard',
        'rewrite' => array('slug' => 'servicios'),
    ));
    
    // Register Project post type
    register_post_type('project', array(
        'labels' => array(
            'name' => __('Proyectos', 'transport-tech'),
            'singular_name' => __('Proyecto', 'transport-tech'),
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-portfolio',
        'rewrite' => array('slug' => 'proyectos'),
    ));
}
add_action('init', 'transport_tech_register_post_types');

// Register widget areas
function transport_tech_widgets_init() {
    register_sidebar(array(
        'name'          => __('Barra lateral', 'transport-tech'),
        'id'            => 'sidebar-1',
        'description'   => __('Añade widgets aquí para que aparezcan en la barra lateral.', 'transport-tech'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'transport_tech_widgets_init');

// Custom function to estimate reading time
function estimate_reading_time($content) {
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / 200); // Assuming 200 words per minute
    return $reading_time;
}

// Process contact form submission
function transport_tech_process_contact_form() {
    if (!isset($_POST['contact_nonce']) || !wp_verify_nonce($_POST['contact_nonce'], 'contact_form_nonce')) {
        wp_die('Security check failed');
    }
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $message = sanitize_textarea_field($_POST['message']);
    
    $to = get_option('admin_email');
    $subject = 'Nuevo mensaje de contacto de ' . $name;
    $body = "Nombre: $name\n\nEmail: $email\n\nMensaje:\n$message";
    $headers = array('From: ' . $name . ' <' . $email . '>');
    
    wp_mail($to, $subject, $body, $headers);
    
    wp_redirect(add_query_arg('contact', 'success', wp_get_referer()));
    exit;
}
add_action('admin_post_submit_contact_form', 'transport_tech_process_contact_form');
add_action('admin_post_nopriv_submit_contact_form', 'transport_tech_process_contact_form');

// Theme customizer settings
function transport_tech_customize_register($wp_customize) {
    // Company Information Section
    $wp_customize->add_section('company_info', array(
        'title' => __('Información de la Empresa', 'transport-tech'),
        'priority' => 30,
    ));
    
    // Company Address
    $wp_customize->add_setting('company_address', array(
        'default' => 'Av. Tecnológica 123, Ciudad Innovación',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('company_address', array(
        'label' => __('Dirección', 'transport-tech'),
        'section' => 'company_info',
        'type' => 'text',
    ));
    
    // Company Email
    $wp_customize->add_setting('company_email', array(
        'default' => 'info@transporttech.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('company_email', array(
        'label' => __('Email', 'transport-tech'),
        'section' => 'company_info',
        'type' => 'email',
    ));
    
    // Company Phone
    $wp_customize->add_setting('company_phone', array(
        'default' => '+1 (555) 123-4567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('company_phone', array(
        'label' => __('Teléfono', 'transport-tech'),
        'section' => 'company_info',
        'type' => 'text',
    ));
    
    // Company Hours
    $wp_customize->add_setting('company_hours', array(
        'default' => 'Lunes a Viernes: 9:00 AM - 6:00 PM',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('company_hours', array(
        'label' => __('Horario de Atención', 'transport-tech'),
        'section' => 'company_info',
        'type' => 'text',
    ));
    
    // Social Media Section
    $wp_customize->add_section('social_media', array(
        'title' => __('Redes Sociales', 'transport-tech'),
        'priority' => 40,
    ));
    
    // Facebook
    $wp_customize->add_setting('social_facebook', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('social_facebook', array(
        'label' => __('Facebook', 'transport-tech'),
        'section' => 'social_media',
        'type' => 'url',
    ));
    
    // Instagram
    $wp_customize->add_setting('social_instagram', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('social_instagram', array(
        'label' => __('Instagram', 'transport-tech'),
        'section' => 'social_media',
        'type' => 'url',
    ));
    
    // Twitter
    $wp_customize->add_setting('social_twitter', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('social_twitter', array(
        'label' => __('Twitter', 'transport-tech'),
        'section' => 'social_media',
        'type' => 'url',
    ));
    
    // LinkedIn
    $wp_customize->add_setting('social_linkedin', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('social_linkedin', array(
        'label' => __('LinkedIn', 'transport-tech'),
        'section' => 'social_media',
        'type' => 'url',
    ));
    
    // Footer Section
    $wp_customize->add_section('footer_settings', array(
        'title' => __('Pie de Página', 'transport-tech'),
        'priority' => 50,
    ));
    
    // Footer Description
    $wp_customize->add_setting('footer_description', array(
        'default' => 'Transformando el sector transporte con soluciones tecnológicas innovadoras desde 2013.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_description', array(
        'label' => __('Descripción', 'transport-tech'),
        'section' => 'footer_settings',
        'type' => 'textarea',
    ));
}
add_action('customize_register', 'transport_tech_customize_register');